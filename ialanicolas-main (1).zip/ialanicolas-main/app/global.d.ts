declare module 'dify-client';
declare module 'uuid';
